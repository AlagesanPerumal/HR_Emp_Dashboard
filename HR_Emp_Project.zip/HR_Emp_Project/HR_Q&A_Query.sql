-- QUESTIONS 

-- 1. What is the gender breakdown of employees in the company?

SELECT gender, count(*) 
FROM HR 
WHERE termdate = '0000-00-00' 
GROUP BY gender;

-- 2. What is the race/ethinicity breakedown employees in the company?

SELECT race, count(*) AS COUNT 
FROM HR 
WHERE termdate = '0000-00-00' 
GROUP BY race 
ORDER BY COUNT DESC;

-- 3. What is the age distribution of employees in the company?

SELECT MIN(age) AS Younger, MAX(age) AS Older
FROM HR 
WHERE termdate != '0000-00-00';

SELECT 
CASE 
WHEN age >= 21 AND age <= 30 THEN '21 - 30'
WHEN age >= 31 AND age <= 40 THEN '31 - 40'
WHEN age >= 41 AND age <= 50 THEN '41 - 50'
WHEN age >= 51 AND age <= 58 THEN '51 - 60'
ELSE '60+'
END AS age_group, gender, count(*) AS count
FROM HR
WHERE termdate = '0000-00-00'
GROUP BY age_group, gender
ORDER BY age_group, gender;

-- 4. How many employees work at headquarters versus remote locations?

SELECT location, count(*) AS count 
FROM HR 
WHERE termdate = '0000-00-00' 
GROUP BY location; 

-- 5. What is the average length of employment for employees who have been terminated?

SELECT COUNT(*) AS num_of_emp_term, round(avg(datediff(termdate, hire_date)/365)) AS 'avg_length of employment in yr'
FROM HR 
 WHERE termdate != '0000-00-00';
 
 -- 6. How does the gender distribution vary across departments and job titels?
 
 SELECT department, gender, count(*) AS count FROM HR GROUP BY department,gender ORDER BY department;
 
 -- 7. What is the distribution of job title across the company?
 
 SELECT jobtitle, gender, count(*) AS count 
 FROM HR 
 WHERE termdate = '0000-00-00' 
 GROUP BY jobtitle, gender 
 ORDER BY count DESC;
 
 -- 8. Which department has highest turnover rate?
 
 SELECT department, 
 total_count,
 terminated_count,
 terminated_count/total_count AS terminated_rate
 FROM 
 (SELECT 
 department, 
 count(*) AS total_count, 
 SUM(
 CASE 
 WHEN termdate <> '0000-00-00' AND termdate <= CURDATE() THEN 1 
 ELSE 0
 END) AS terminated_count
 FROM HR GROUP BY department) AS innerquery
 ORDER BY terminated_rate DESC;
 
 -- 9. What is the distribution of employees across locations by city and state?
 
 SELECT location_state, count(*) AS count
 FROM HR
 WHERE termdate = '0000-00-00'
 group by location_state
 order by count desc;
 
 -- 10. How has the company's employee count changed over time based on hire and term dates?
 
 SELECT 
 year,
 hires, 
 terminations,
 hires - terminations AS net_change,
 round((hires - terminations)/ hires * 100,2) AS net_change_percent
 FROM (
 SELECT YEAR(hire_date) AS year,
 count(hire_date) as hires,
 SUM(
 CASE WHEN termdate <> '0000-00-00' THEN 1 ELSE 0 END) AS terminations
 FROM HR GROUP BY year) AS innerquery 
 ORDER BY year;
 
 -- 11. What is the tenure distribution for each department?
 
 SELECT department, round(avg(datediff(termdate, hire_date)/365),0) AS avg_tenure
 FROM HR
 WHERE termdate <> '0000-00-00'
 GROUP BY department;