CREATE Database HR_Project;
USE HR_Project;
SHOW TABLES;
describe HR;

ALTER TABLE HR CHANGE ï»¿id EmpID VARCHAR(200);

UPDATE HR 
SET birthdate = 
CASE 
WHEN birthdate LIKE '%/%' THEN date_format(STR_TO_DATE(birthdate, '%m/%d/%Y'), '%Y-%m-%d')
WHEN birthdate LIKE '%-%' THEN date_format(STR_TO_DATE(birthdate, '%m-%d-%Y'), '%Y-%m-%d')
ELSE null
END;

UPDATE HR 
SET hire_date = 
CASE 
WHEN hire_date LIKE '%/%' THEN date_format(STR_TO_DATE(hire_date, '%m/%d/%Y'), '%Y-%m-%d')
WHEN hire_date LIKE '%-%' THEN date_format(STR_TO_DATE(hire_date, '%m-%d-%Y'), '%Y-%m-%d')
ELSE null
END;

ALTER TABLE HR MODIFY COLUMN hire_date DATE;

ALTER TABLE HR MODIFY COLUMN birthdate DATE;

UPDATE HR SET termdate = date(str_to_date(termdate, '%Y-%m-%d %H:%i:%s UTC'))
WHERE termdate IS NOT NULL AND termdate != '';

SELECT termdate FROM HR; 

ALTER TABLE HR MODIFY COLUMN termdate DATE;

SELECT @@GLOBAL.sql_mode global, @@SESSION.sql_mode session;

SET sql_mode = '';
UPDATE HR SET termdate = '0000-00-00' WHERE termdate = CURDATE();

SELECT gender, birthdate FROM HR;

ALTER TABLE HR ADD COLUMN age INT;

UPDATE HR SET age = YEAR(CURDATE()) - YEAR(birthdate);

SELECT birthdate, age FROM HR WHERE YEAR(birthdate) > 2023;